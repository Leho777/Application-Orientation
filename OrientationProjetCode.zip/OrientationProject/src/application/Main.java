package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;

import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;


public class Main extends Application {
	@Override
    public void start(Stage primaryStage) {
        try {
            // Charger le fichier FXML pour la vue d'accueil
            // Assurez-vous que le chemin est correct et correspond � l'emplacement du fichier FXML
            Parent accueilView = FXMLLoader.load(getClass().getResource("/com/cytech/view/FXML/Accueil.fxml"));
            
            // D�finir le titre de la fen�tre principale
            primaryStage.setTitle("Orientation des �tudiants");
            
            // D�finir la sc�ne avec la vue d'accueil et sp�cifier la taille de la fen�tre
            primaryStage.setScene(new Scene(accueilView, 800, 600)); // Vous pouvez ajuster la taille si n�cessaire
            
            // Afficher la fen�tre principale
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	
	public static void main(String[] args) {
		System.setProperty("org.apache.poi.util.POILogger", "org.apache.poi.util.NullLogger");
		launch(args);
		
		//Test de r�cup�ration du bool�en et de sa modification
		/*
		GestionAccesVoeux g = new GestionAccesVoeux();
		System.out.println(g.getBoolValue());
		//On attribut � boolValue sa valeur inverse
		g.setBoolValue(!g.getBoolValue());
		g.modifierJson();
		System.out.println(g.getBoolValue());
		*/
		
		//Test pour lancer l'operation
		/*
		lancerOperation();
		
		EtudiantCollection etudiantCollection = new EtudiantCollection();
        
        // Lire les �tudiants depuis le fichier JSON
        etudiantCollection.lireJson();
        
        // Afficher la liste tri�e
        for (Etudiant etudiant : etudiantCollection.getCollection()) {
            System.out.println(etudiant.getPrenom());
            System.out.println(etudiant.getResultat());
        }
        */
		
	}
	
}
