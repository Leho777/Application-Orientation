package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        try {
            // Charger le fichier FXML pour la vue d'accueil
            // Assurez-vous que le chemin est correct et correspond � l'emplacement du fichier FXML
            Parent accueilView = FXMLLoader.load(getClass().getResource("/com/cytech/view/FXML/Accueil.fxml"));
            
            // D�finir le titre de la fen�tre principale
            primaryStage.setTitle("Orientation des �tudiants");
            
            // D�finir la sc�ne avec la vue d'accueil et sp�cifier la taille de la fen�tre
            primaryStage.setScene(new Scene(accueilView, 800, 600)); // Vous pouvez ajuster la taille si n�cessaire
            
            // Afficher la fen�tre principale
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // M�thode main pour lancer l'application
    public static void main(String[] args) {
        launch(args);
    }
}
