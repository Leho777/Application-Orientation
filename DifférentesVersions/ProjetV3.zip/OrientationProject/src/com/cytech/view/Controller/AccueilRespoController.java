package com.cytech.view.Controller;

import java.io.IOException;

import com.cytech.model.ChangeScene;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;


public class AccueilRespoController {

	private ChangeScene sceneChanger = new ChangeScene(); // Cr�ez une instance de ChangeScene
	
	@FXML
	private Label prenomLabel;

	@FXML
	private Label nomLabel;
	
	
	
	@FXML
	private void handleDeconnexion(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/Accueil.fxml", event);
	}
	
	@FXML
	private void handleGererVoeux(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/GererVoeuxRespo.fxml", event);
	}
}
