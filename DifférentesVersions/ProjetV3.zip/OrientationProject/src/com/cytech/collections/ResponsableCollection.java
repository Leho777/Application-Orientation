package com.cytech.collections;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.cytech.individu.Responsable;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ResponsableCollection {
    // Liste des responsables dans la collection
    private List<Responsable> collection;
    
    // Nom du fichier JSON contenant les donn�es des responsables
    private static final String FILENAME = "BDD/responsable.json";
    
    // Objet Gson pour la s�rialisation et la d�s�rialisation des objets
    private static final Gson gson = new Gson();
    
    // Constructeur pour initialiser la collection des responsables
    public ResponsableCollection() {
        this.collection = new ArrayList<>();
    }

    // Getter pour obtenir la collection des responsables
    public List<Responsable> getCollection() {
        return collection;
    }

    // Setter pour d�finir la collection des responsables
    public void setCollection(List<Responsable> collection) {
        this.collection = collection;
    }
    
    // M�thode pour lire les responsables depuis le fichier JSON et les stocker dans la collection
    public void lireJson() {
        try (FileReader reader = new FileReader(FILENAME)) {
            // Utilisation de TypeToken pour r�cup�rer la liste des responsables depuis le JSON
            List<Responsable> responsables = gson.fromJson(reader, new TypeToken<List<Responsable>>(){}.getType());
            setCollection(responsables);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // M�thode pour ajouter un responsable � la collection et mettre � jour le fichier JSON
    // ATTENTION: Pour utiliser cette fonction, la collection doit d'abord �tre initialis�e avec le contenu du fichier JSON
    // Cette fonction pourrait �tre utilis�e pour des fonctionnalit�s comme la r�cup�ration de mot de passe
    public void ajouterResponsable(Responsable responsable) {
        // Rechercher et remplacer le responsable existant ou ajouter le nouveau
        boolean responsableExiste = false;
        for (int i = 0; i < this.collection.size(); i++) {
            if (this.collection.get(i).getMail().equals(responsable.getMail())) {
                this.collection.set(i, responsable);
                responsableExiste = true;
                break;
            }
        }
        
        // Si le responsable n'existe pas encore, l'ajouter � la collection
        if (!responsableExiste) {
            this.collection.add(responsable);
        }

        // �crire la collection mise � jour dans le fichier JSON
        try (FileWriter writer = new FileWriter(FILENAME)) {
            gson.toJson(this.collection, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
