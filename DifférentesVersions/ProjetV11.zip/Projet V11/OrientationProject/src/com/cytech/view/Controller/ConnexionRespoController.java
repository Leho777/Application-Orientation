package com.cytech.view.Controller;

import java.io.IOException;



import com.cytech.collections.ResponsableCollection;
import com.cytech.individu.Responsable;
import com.cytech.model.BoiteDeDialogue;
import com.cytech.model.ChangeScene;
import com.cytech.model.RespoSession;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.TextField;


public class ConnexionRespoController {

	private ChangeScene sceneChanger = new ChangeScene(); // Cr�ez une instance de ChangeScene
	private BoiteDeDialogue dialogue = new BoiteDeDialogue();

	@FXML
	private TextField emailField;

	@FXML
	private TextField passwordField;
	
	

	@FXML
	private void handleSeConnecter(ActionEvent event) throws IOException {
		
		String email = emailField.getText();
		String password = passwordField.getText();
		int var = 0;
		
		// Cr�er une collection de responsables
		ResponsableCollection responsableCollection = new ResponsableCollection();
		responsableCollection.lireJson();

		for (Responsable respo : responsableCollection.getCollection()) {
			if (respo.getMail().equals(email) && respo.getMdpRespo().equals(password)) {
				var=1;
				RespoSession.getInstance().setRespoConnecte(respo);
				dialogue.Welcome("Bienvenue Monsieur "+respo.getNom());
			}
		}
		if(var==1) {
			sceneChanger.changeScene("/com/cytech/view/FXML/AccueilRespo.fxml", event);
		}
		else {
			dialogue.Error("La connexion a �chou� : Email ou mot de passe incorrect !");
		}

	}

	@FXML
	private void handleRetour(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/Accueil.fxml", event);
	}

	@FXML
	private void handleMdpOublie(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/MdpOublieRespo.fxml", event);
	}
}
