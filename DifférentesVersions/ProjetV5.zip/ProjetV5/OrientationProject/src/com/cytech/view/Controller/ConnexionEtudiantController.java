package com.cytech.view.Controller;

import java.io.IOException;
import com.cytech.collections.EtudiantCollection;
import com.cytech.model.ChangeScene;
import com.cytech.model.EtudiantSession;
import com.cytech.individu.Etudiant;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class ConnexionEtudiantController {

    // Instance de ChangeScene pour changer de sc�ne
    private ChangeScene sceneChanger = new ChangeScene();

    @FXML
    private TextField textNum; // Champ de texte pour le num�ro �tudiant

    @FXML
    private TextField textmdp; // Champ de texte pour le mot de passe

    @FXML
    private Button seConnecter; // Bouton pour se connecter

    // M�thode pour g�rer l'action de retour � l'�cran d'accueil
    @FXML
    private void handleRetour(ActionEvent event) throws IOException {
        sceneChanger.changeScene("/com/cytech/view/FXML/Accueil.fxml", event);
    }

    // M�thode pour g�rer l'action de mot de passe oubli�
    @FXML
    private void handleMdpOublie(ActionEvent event) throws IOException {
        sceneChanger.changeScene("/com/cytech/view/FXML/MdpOublieEtudiant.fxml", event);
    }

    // M�thode pour g�rer l'action de connexion
    @FXML
    private void handleSeConnecter(ActionEvent event) throws IOException {
        // Cr�er une collection d'�tudiants
        EtudiantCollection etudiantCollection = new EtudiantCollection();

        // R�cup�rer les valeurs des champs de texte
        int codeEtu;
        try {
            codeEtu = Integer.parseInt(textNum.getText());
        } catch (NumberFormatException e) {
            System.out.println("Num�ro �tudiant invalide.");
            return;
        }
        String mdp = textmdp.getText();

        // Lire les donn�es depuis le fichier JSON
        etudiantCollection.lireJson();

        // V�rifier les informations de connexion
        for (Etudiant etudiant : etudiantCollection.getCollection()) {
            if (etudiant.getNumEtu() == codeEtu && etudiant.getMdpEtu().equals(mdp)) {
                // Si les informations sont correctes, connecter l'�tudiant
                EtudiantSession.getInstance().setEtudiantConnecte(etudiant);
                sceneChanger.changeScene("/com/cytech/view/FXML/AccueilEtudiant.fxml", event);
                return;
            }
        }

        // Si les informations sont incorrectes, vider les champs de texte et afficher un message
        textNum.clear();
        textmdp.clear();
        System.out.println("Code incorrect. Veuillez r�essayer.");
    }
}
