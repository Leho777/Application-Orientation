package com.cytech.view.Controller;

import java.io.IOException;
import com.cytech.model.*;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class ResultatEtudiantController {
	
	private ChangeScene sceneChanger = new ChangeScene(); // Cr�ez une instance de ChangeScene

	@FXML
	private void handleRetour(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/AccueilEtudiant.fxml", event);
	}
}