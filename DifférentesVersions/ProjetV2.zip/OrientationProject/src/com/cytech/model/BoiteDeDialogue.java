package com.cytech.model;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class BoiteDeDialogue {

    // Attribut qui va permettre d'ouvrir une bo�te de dialogue
    private Stage dialogStage;

    /**
     * D�finit la fen�tre (Stage) de cette bo�te de dialogue.
     * @param dialogStage la fen�tre � utiliser pour la bo�te de dialogue
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    /**
     * Affiche une bo�te de dialogue de bienvenue avec un message personnalis�.
     * @param message le message � afficher dans la bo�te de dialogue
     */
    public void Welcome(String message) {
        // Cr�er une bo�te de dialogue de type CONFIRMATION
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.initOwner(dialogStage); // Initialiser la bo�te de dialogue avec la fen�tre principale
        alert.setTitle("CONNECTE"); // D�finir le titre de la bo�te de dialogue
        alert.setHeaderText("Connexion �tablie avec succ�s !"); // D�finir le texte de l'en-t�te
        alert.setContentText(message); // D�finir le contenu du message
        alert.showAndWait(); // Afficher la bo�te de dialogue et attendre que l'utilisateur la ferme
    }

    /**
     * Affiche une bo�te de dialogue d'erreur avec un message personnalis�.
     * @param message le message � afficher dans la bo�te de dialogue
     */
    public void Error(String message) {
        // Cr�er une bo�te de dialogue de type ERROR
        Alert alert = new Alert(AlertType.ERROR);
        alert.initOwner(dialogStage); // Initialiser la bo�te de dialogue avec la fen�tre principale
        alert.setTitle("ERREUR"); // D�finir le titre de la bo�te de dialogue
        alert.setHeaderText("Une erreur est survenue !"); // D�finir le texte de l'en-t�te
        alert.setContentText(message); // D�finir le contenu du message
        alert.showAndWait(); // Afficher la bo�te de dialogue et attendre que l'utilisateur la ferme
    }

    /**
     * Affiche une bo�te de dialogue d'information avec un message personnalis�.
     * @param message le message � afficher dans la bo�te de dialogue
     */
    public void Information(String message) {
        // Cr�er une bo�te de dialogue de type INFORMATION
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.initOwner(dialogStage); // Initialiser la bo�te de dialogue avec la fen�tre principale
        alert.setTitle("INFORMATION"); // D�finir le titre de la bo�te de dialogue
        alert.setHeaderText(""); // D�finir le texte de l'en-t�te (vide dans ce cas)
        alert.setContentText(message); // D�finir le contenu du message
        alert.showAndWait(); // Afficher la bo�te de dialogue et attendre que l'utilisateur la ferme
    }
}
