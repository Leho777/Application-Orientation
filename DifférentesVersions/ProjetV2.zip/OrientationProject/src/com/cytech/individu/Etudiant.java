package com.cytech.individu;

import java.util.ArrayList;
import java.util.Objects;

public class Etudiant {
    // Attributs de la classe Etudiant
    private String nom;               // Nom de l'�tudiant
    private String prenom;            // Pr�nom de l'�tudiant
    private String mail;              // Adresse email de l'�tudiant
    private String mdpEtu;            // Mot de passe de l'�tudiant
    private int numEtu;               // Num�ro de l'�tudiant
    private String filiere;           // Fili�re de l'�tudiant
    private double moyGen;            // Moyenne g�n�rale de l'�tudiant
    private ArrayList<Voeux> listeVoeux = new ArrayList<>(); // Liste des voeux de l'�tudiant
    private Voeux resultat;           // R�sultat des voeux de l'�tudiant

    // Getters et Setters pour chaque attribut
    /**
     * @return the nom
     */
    public String getNom() {
        return nom;
    }

    /**
     * @param nom the nom to set
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * @return the prenom
     */
    public String getPrenom() {
        return prenom;
    }

    /**
     * @param prenom the prenom to set
     */
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the mdpEtu
     */
    public String getMdpEtu() {
        return mdpEtu;
    }

    /**
     * @param mdpEtu the mdpEtu to set
     */
    public void setMdpEtu(String mdpEtu) {
        this.mdpEtu = mdpEtu;
    }

    /**
     * @return the numEtu
     */
    public int getNumEtu() {
        return numEtu;
    }

    /**
     * @param numEtu the numEtu to set
     */
    public void setNumEtu(int numEtu) {
        this.numEtu = numEtu;
    }

    /**
     * @return the filiere
     */
    public String getFiliere() {
        return filiere;
    }

    /**
     * @param filiere the filiere to set
     */
    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    /**
     * @return the moyGen
     */
    public double getMoyGen() {
        return moyGen;
    }

    /**
     * @param moyGen the moyGen to set
     */
    public void setMoyGen(double moyGen) {
        this.moyGen = moyGen;
    }

    /**
     * @return the listVoeux
     */
    public ArrayList<Voeux> getListeVoeux() {
        return listeVoeux;
    }

    /**
     * @param listeVoeux the listeVoeux to set
     */
    public void setListVoeux(ArrayList<Voeux> listeVoeux) {
        this.listeVoeux = listeVoeux;
    }

    /**
     * @return the resultat
     */
    public Voeux getResultat() {
        return resultat;
    }

    /**
     * @param resultat the resultat to set
     */
    public void setResultat(Voeux resultat) {
        this.resultat = resultat;
    }

    // M�thode hashCode pour g�n�rer un code de hachage unique pour l'objet
    @Override
    public int hashCode() {
        return Objects.hash(filiere, listeVoeux, mail, mdpEtu, moyGen, nom, numEtu, prenom, resultat);
    }

    // M�thode equals pour comparer deux objets Etudiant
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Etudiant other = (Etudiant) obj;
        return Objects.equals(filiere, other.filiere) && Objects.equals(listeVoeux, other.listeVoeux)
                && Objects.equals(mail, other.mail) && Objects.equals(mdpEtu, other.mdpEtu)
                && Double.doubleToLongBits(moyGen) == Double.doubleToLongBits(other.moyGen)
                && Objects.equals(nom, other.nom) && numEtu == other.numEtu && Objects.equals(prenom, other.prenom)
                && Objects.equals(resultat, other.resultat);
    }

    // M�thode toString pour afficher les informations de l'�tudiant sous forme de cha�ne de caract�res
    @Override
    public String toString() {
        return "Etudiant [nom=" + nom + ", prenom=" + prenom + ", mail=" + mail + ", mdpEtu=" + mdpEtu + ", numEtu="
                + numEtu + ", filiere=" + filiere + ", moyGen=" + moyGen + ", listeVoeux=" + listeVoeux + ", resultat="
                + resultat + "]";
    }
}
