package com.cytech.collections;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.cytech.individu.Voeux;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class VoeuxCollection {
    // Liste des voeux dans la collection
    private List<Voeux> collection;
    
    // Nom du fichier JSON contenant les donn�es des voeux
    private static final String FILENAME = "BDD/voeux.json";
    
    // Objet Gson pour la s�rialisation et la d�s�rialisation des objets
    private static final Gson gson = new Gson();
    
    // Constructeur pour initialiser la collection des voeux
    public VoeuxCollection() {
        this.collection = new ArrayList<>();
    }

    // Getter pour obtenir la collection des voeux
    public List<Voeux> getCollection() {
        return collection;
    }

    // Setter pour d�finir la collection des voeux
    public void setCollection(List<Voeux> collection) {
        this.collection = collection;
    }
    
    // M�thode pour lire les voeux depuis le fichier JSON et les stocker dans la collection
    public void lireJson() {
        try (FileReader reader = new FileReader(FILENAME)) {
            // Utilisation de TypeToken pour r�cup�rer la liste des voeux depuis le JSON
            List<Voeux> voeux = gson.fromJson(reader, new TypeToken<List<Voeux>>(){}.getType());
            setCollection(voeux);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // M�thode pour ajouter un voeux � la collection et mettre � jour le fichier JSON
    // ATTENTION: Pour utiliser cette fonction, la collection doit d'abord �tre initialis�e avec le contenu du fichier JSON
    // Cette fonction pourrait �tre utilis�e pour ajouter ou mettre � jour un voeux dans la collection
    public void ajouterResponsable(Voeux voeux) {
        // Rechercher et remplacer le voeux existant ou ajouter le nouveau
        boolean voeuxExiste = false;
        for (int i = 0; i < this.collection.size(); i++) {
            if (this.collection.get(i).getIdVoeux() == voeux.getIdVoeux()) {
                this.collection.set(i, voeux);
                voeuxExiste = true;
                break;
            }
        }
        
        // Si le voeux n'existe pas encore, l'ajouter � la collection
        if (!voeuxExiste) {
            this.collection.add(voeux);
        }

        // �crire la collection mise � jour dans le fichier JSON
        try (FileWriter writer = new FileWriter(FILENAME)) {
            gson.toJson(this.collection, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
