package com.cytech.view.Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.cytech.collections.VoeuxCollection;
import com.cytech.individu.Voeux;
import com.cytech.model.BoiteDeDialogue;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ModifierVoeuxController {

	// Cr�er une instance de BoiteDeDialogue
	private BoiteDeDialogue dialogue = new BoiteDeDialogue();
	// Instance de VoeuxCollection pour g�rer les voeux
	private VoeuxCollection voeuxCollection = new VoeuxCollection();

	@FXML
	private TextField nomTextField;
	@FXML
	private TextField filiereTextField;
	@FXML
	private TextField nbPlaceTextField;
	@FXML
	private TextField descriptionTextField;
	@FXML
	private TextField idTextField;

	private Voeux voeu;
	private int id;

	public void initialisation(Voeux voeu) {
		this.voeu = voeu;
		// Remplir les champs avec les donn�es du voeu s�lectionn�
		nomTextField.setText(voeu.getNom());
		String filieres = String.join(", ", voeu.getFiliereEligible());
		filiereTextField.setText(filieres);
		nbPlaceTextField.setText(String.valueOf(voeu.getNbPlace()));
		descriptionTextField.setText(voeu.getDescription());
		idTextField.setText(String.valueOf(voeu.getIdVoeux()));
		id=voeu.getIdVoeux();
	}

	@FXML
	private void handleEnregistrerModification(ActionEvent event) throws IOException {
		int var=1;
		int var2=1;
		voeuxCollection.lireJson();
		// Mettre � jour les donn�es du voeu avec les nouvelles valeurs des champs
		String[] filieresArray = filiereTextField.getText().split(", ");
		ArrayList<String> filieresList = new ArrayList<>(Arrays.asList(filieresArray));
		voeu.setFiliereEligible(filieresList);
		voeu.setNbPlace(Double.parseDouble(nbPlaceTextField.getText()));
		voeu.setDescription(descriptionTextField.getText());
		voeu.setIdVoeux(Integer.parseInt(idTextField.getText()));
		if(voeu.getIdVoeux()==id) {
			var2=2;
		}
		for(Voeux voeuxExistants : voeuxCollection.getCollection()) {
			if(voeuxExistants.getIdVoeux()==voeu.getIdVoeux()&&var2!=2) {
				var=0;
				dialogue.Error("Cet ID est d�j� attribu� � une option !");
			}
		}
		if(var==1) {
			voeuxCollection.mettreAJour(voeu);
			voeu.setNom(nomTextField.getText());
			voeuxCollection.mettreAJour(voeu);
			dialogue.Confirmation("Les modifications ont bien �t� prises en compte !");
			// Fermer la fen�tre de modification
			((Stage) nomTextField.getScene().getWindow()).close();
		}
	}

	@FXML
	private void handleRetourMenu(ActionEvent event) throws IOException {
		// Fermer la fen�tre de modification
		((Stage) nomTextField.getScene().getWindow()).close();
	}
}
