package com.cytech.model;

public class BoiteDeDialogue {

}
