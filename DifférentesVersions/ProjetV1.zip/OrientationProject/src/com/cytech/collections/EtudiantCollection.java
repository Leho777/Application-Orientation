package com.cytech.collections;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import java.io.FileReader;
import java.io.IOException;
import com.cytech.individu.Etudiant;
import com.google.gson.reflect.TypeToken;
import java.io.FileWriter;


public class EtudiantCollection {
	private List<Etudiant> collection;
    private static final String FILENAME = "BDD/etudiant.json"; // 
    private static final Gson gson = new Gson();
    
 // Constructeur pour initialiser le stock de boissons
    public EtudiantCollection() {
      this.collection = new ArrayList<>();
    }

    public List<Etudiant> getCollection() {
      return collection;
    }

    public void setCollection(List<Etudiant> collection) {
      this.collection = collection;
    }
    
    //Cette fonction lit le fichier json et met tous les etudiants dans collection (c'est un deuxi�me setter)
    public void lireJson() {
        try (FileReader reader = new FileReader(FILENAME)) {
            // Utilisation de TypeToken pour r�cup�rer la liste des �tudiants
            List<Etudiant> etudiants = gson.fromJson(reader, new TypeToken<List<Etudiant>>(){}.getType());
            setCollection(etudiants);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

 // M�thode pour ajouter un �tudiant au fichier JSON 
 // ATTENTION (pour utiliser cette fonction il faut que la collection soit constitu�e de ce qu'il y a initialement dans le json)
 // Pour remplir la liste des voeux on l'�tudiant, on modifie sa listeVoeux et ensuite on fait ajouterEtudiant avec la nouvelle version de l'�tudiant
    public void ajouterEtudiant(Etudiant etudiant) {
    	
    	// Rechercher et remplacer l'�tudiant existant ou ajouter le nouveau
        boolean etudiantExiste = false;
        for (int i = 0; i < this.collection.size(); i++) {
            if (this.collection.get(i).getNumEtu() == etudiant.getNumEtu()) {
                this.collection.set(i, etudiant);
                etudiantExiste = true;
                break;
            }
        }
        
        if (!etudiantExiste) {
            this.collection.add(etudiant);
        }

        // �crire la liste mise � jour dans le fichier JSON
        try (FileWriter writer = new FileWriter(FILENAME)) {
            gson.toJson(this.collection, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
