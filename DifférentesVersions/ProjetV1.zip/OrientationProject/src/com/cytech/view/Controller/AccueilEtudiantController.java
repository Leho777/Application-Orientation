package com.cytech.view.Controller;

import java.io.IOException;
import com.cytech.model.*;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class AccueilEtudiantController {
	
	private ChangeScene sceneChanger = new ChangeScene(); // Cr�ez une instance de ChangeScene

	@FXML
	private void handleSeDeconnecter(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/Accueil.fxml", event);
	}
	
	@FXML
	private void handleDonnees(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/DonneesEtudiant.fxml", event);
	}
	
	@FXML
	private void handleVoeuxDispo(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/VoeuxDispoEtudiant.fxml", event);
	}
	
	@FXML
	private void handleFicheVoeux(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/FicheVoeuxEtudiant.fxml", event);
	}
	
	@FXML
	private void handleResultat(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/ResultatEtudiant.fxml", event);
	}
	
}
