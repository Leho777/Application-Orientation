package com.cytech.view.Controller;

import java.io.IOException;
import com.cytech.model.*;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class AccueilController {
	
	private ChangeScene sceneChanger = new ChangeScene(); // Cr�ez une instance de ChangeScene

	@FXML
	private void handleEtudiant(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/ConnexionEtudiant.fxml", event);
	}
	
	@FXML
	private void handleRespo(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/ConnexionRespo.fxml", event);
	}
	
}
