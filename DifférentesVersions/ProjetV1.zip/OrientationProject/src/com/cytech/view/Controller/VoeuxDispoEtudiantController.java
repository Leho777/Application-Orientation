package com.cytech.view.Controller;

import java.io.IOException;

import com.cytech.collections.VoeuxCollection;
import com.cytech.individu.Voeux;
import com.cytech.model.*;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;

import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class VoeuxDispoEtudiantController {

	private ChangeScene sceneChanger = new ChangeScene(); // Cr�ez une instance de ChangeScene

	@FXML
	private void handleRetour(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/AccueilEtudiant.fxml", event);
	}

	@FXML
	private TableView<Voeux> tableVoeux;

	@FXML
	private TableColumn<Voeux, String> nomVoeux;

	@FXML
	private TableColumn<Voeux, Double> nbPlace;

	// M�thode pour initialiser le contr�leur apr�s que son contenu a �t�
	// compl�tement charg�
	@FXML
    private void initialize() {
    	// Cr�er une collection de voeux
        VoeuxCollection voeuxCollection = new VoeuxCollection();
        
        // Lis dans le JSON
        voeuxCollection.lireJson();
        
        // Configurer les colonnes du tableau
        nomVoeux.setCellValueFactory(new PropertyValueFactory<>("nom"));
        
        // Configurer les colonnes du tableau
        nbPlace.setCellValueFactory(new PropertyValueFactory<>("nbPlace"));

		// Remplir le tableau avec les donn�es des commandes
        tableVoeux.setItems(FXCollections.observableArrayList(voeuxCollection.getCollection()));
    }

}
