package com.cytech.view.Controller;

import java.io.IOException;

import com.cytech.collections.EtudiantCollection;
import com.cytech.collections.VoeuxCollection;
import com.cytech.individu.*;

import com.cytech.model.ChangeScene;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ConnexionEtudiantController {

	private ChangeScene sceneChanger = new ChangeScene(); // Cr�ez une instance de ChangeScene

	@FXML
	private TextField textNum;

	@FXML
	private TextField textmdp;

	@FXML
	private Button seConnecter;

	@FXML
	private void handleRetour(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/Accueil.fxml", event);
	}

	@FXML
	private void handleMdpOublie(ActionEvent event) throws IOException {
		sceneChanger.changeScene("/com/cytech/view/FXML/MdpOublieEtudiant.fxml", event);
	}

	@FXML
	private void handleSeConnecter(ActionEvent event) throws IOException {
		// Cr�er une collection d'�tudiants
		EtudiantCollection etudiantCollection = new EtudiantCollection();

		int codeEtu = Integer.parseInt(textNum.getText());
		String mdp = textmdp.getText();
		
		
		// Lis dans le JSON
		etudiantCollection.lireJson();
		
		
		for (int i = 0; i < etudiantCollection.getCollection().size(); i++) {
			if (etudiantCollection.getCollection().get(i).getNumEtu() == codeEtu 
					&& etudiantCollection.getCollection().get(i).getMdpEtu().equals(mdp)) {
	 
				sceneChanger.changeScene("/com/cytech/view/FXML/AccueilEtudiant.fxml", event);
			}
			
		}
        // Vide le champ de texte du code personnel en cas de code incorrect
        textNum.setText("");
        textmdp.setText("");
        System.out.println("Code incorrect. Veuillez r�essayer.");
	}

}
