package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;



public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
	    try {
	        // Assurez-vous que le chemin est correct et correspond � l'emplacement du fichier FXML
	        Parent accueilView = FXMLLoader.load(getClass().getResource("/com/cytech/view/FXML/Accueil.fxml"));
	        primaryStage.setTitle("Orientation des �tudiants");
	        primaryStage.setScene(new Scene(accueilView, 800, 600)); // Vous pouvez ajuster la taille si n�cessaire
	        primaryStage.show();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
